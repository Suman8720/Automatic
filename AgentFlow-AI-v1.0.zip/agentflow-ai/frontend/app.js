const $ = s => document.querySelector(s);
let state = {agents:[],workflows:[],runs:[]};
async function api(path, options={}) {
  const res = await fetch('/api'+path,{headers:{'Content-Type':'application/json'},...options});
  const data = await res.json().catch(()=>({}));
  if(!res.ok) throw new Error(data.detail || 'Request failed');
  return data;
}
function toast(msg){const t=$('#toast');t.textContent=msg;t.classList.add('show');setTimeout(()=>t.classList.remove('show'),2600)}
function esc(s=''){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
function go(page){document.querySelectorAll('.page').forEach(x=>x.classList.remove('active'));$('#page-'+page).classList.add('active');document.querySelectorAll('.nav').forEach(x=>x.classList.toggle('active',x.dataset.page===page));$('#crumb').textContent=({dashboard:'Overview',agents:'AI Agents',workflows:'Workflows',runs:'Execution history'})[page];$('#sidebar').classList.remove('open')}
document.querySelectorAll('.nav').forEach(b=>b.addEventListener('click',()=>go(b.dataset.page)));
document.querySelectorAll('[data-go]').forEach(b=>b.addEventListener('click',()=>go(b.dataset.go)));
$('#menuBtn').onclick=()=>$('#sidebar').classList.toggle('open');
function render(){
 const s=state.stats||{};
 $('#statAgents').textContent=s.agents||0;$('#statWorkflows').textContent=s.workflows||0;$('#statRuns').textContent=s.executions||0;$('#statSuccess').textContent=(s.success_rate??100)+'%';
 $('#agentCount').textContent=s.agents||0;$('#workflowCount').textContent=s.workflows||0;
 $('#agentsGrid').innerHTML=state.agents.map(a=>`<article class="agent-card"><div class="card-top"><div class="card-symbol">◈</div><div><b>${esc(a.name)}</b><small>${esc(a.role)}</small></div></div><div class="card-desc">${esc(a.instructions)}</div><div class="card-footer"><span class="tag">${esc(a.model)}</span><div class="card-actions"><button class="small-btn" data-edit-agent="${a.id}">Edit</button><button class="small-btn danger" data-delete-agent="${a.id}">Delete</button></div></div></article>`).join('')||'<div class="empty">No agents yet. Create your first personal assistant.</div>';
 $('#workflowsGrid').innerHTML=state.workflows.map(w=>`<article class="workflow-card"><div class="card-top"><div class="card-symbol">⌘</div><div><b>${esc(w.name)}</b><small>${w.steps.length} step(s) · ${w.enabled?'Enabled':'Paused'}</small></div></div><div class="card-desc">${esc(w.description||'No description provided.')}</div><div class="card-footer"><span class="tag">MANUAL TRIGGER</span><div class="card-actions"><button class="small-btn run-btn" data-run="${w.id}">▶ Run</button><button class="small-btn danger" data-delete-workflow="${w.id}">Delete</button></div></div></article>`).join('')||'<div class="empty">No workflows yet. Create one to automate a task.</div>';
 const activity = state.runs.map(r=>`<div class="activity-row"><div class="activity-mark ${r.status==='success'?'':'fail'}">${r.status==='success'?'✓':'!'}</div><div class="activity-copy"><b>${esc(r.workflow_name)}</b><small>${esc(r.status)} · ${(r.log||[]).length} log item(s)</small></div><span class="activity-time">${new Date(r.created_at).toLocaleString()}</span></div>`).join('')||'<div class="empty">No executions yet. Run your first workflow.</div>';
 $('#recentRuns').innerHTML=activity;$('#allRuns').innerHTML=activity;
}
async function refresh(){try{state=await api('/overview');render();}catch(e){toast(e.message)}}
function openModal(title,fields,onSave){$('#modalTitle').textContent=title;$('#modalFields').innerHTML=fields;$('#modal').classList.add('open');$('#modalForm').onsubmit=async e=>{e.preventDefault();const data=onSave(new FormData(e.target));if(data===null)return;try{await data;$('#modal').classList.remove('open');await refresh();toast('Saved successfully')}catch(err){toast(err.message)}}}
function closeModal(){$('#modal').classList.remove('open')}
$('#closeModal').onclick=closeModal;$('#cancelModal').onclick=closeModal;$('#modal').onclick=e=>{if(e.target.id==='modal')closeModal()};
function agentFields(a={}){return `<div class="field"><label>Agent name</label><input name="name" required maxlength="60" value="${esc(a.name||'')}" placeholder="Research assistant"></div><div class="field"><label>Role</label><input name="role" value="${esc(a.role||'Personal assistant')}"></div><div class="field"><label>Instructions</label><textarea name="instructions">${esc(a.instructions||'Be helpful and concise.')}</textarea></div><div class="field"><label>Model</label><select name="model"><option>gpt-4o-mini</option><option>gpt-4.1-mini</option></select></div>`}
$('#newAgent').onclick=()=>openModal('Create AI agent',agentFields(),fd=>api('/agents',{method:'POST',body:JSON.stringify(Object.fromEntries(fd))}));
$('#agentsGrid').addEventListener('click',async e=>{
 const edit=e.target.closest('[data-edit-agent]'),del=e.target.closest('[data-delete-agent]');
 if(edit){const a=state.agents.find(x=>x.id===edit.dataset.editAgent);openModal('Edit AI agent',agentFields(a),fd=>api('/agents/'+a.id,{method:'PUT',body:JSON.stringify(Object.fromEntries(fd))}))}
 if(del&&confirm('Delete this agent?')){try{await api('/agents/'+del.dataset.deleteAgent,{method:'DELETE'});await refresh();toast('Agent deleted')}catch(x){toast(x.message)}}
});
$('#newWorkflow').onclick=()=>openModal('Create workflow',`<div class="field"><label>Workflow name</label><input name="name" required placeholder="Daily planning"></div><div class="field"><label>Description</label><input name="description" placeholder="What should this workflow do?"></div><div class="field"><label>First step</label><select name="type"><option value="log">Log a message (works without AI)</option><option value="ai">Ask AI (requires API key)</option><option value="wait">Wait briefly</option></select></div><div class="field"><label>Step input</label><textarea name="input" placeholder="Message, AI prompt, or wait seconds">Your workflow ran successfully.</textarea></div>`,fd=>{const type=fd.get('type'),input=fd.get('input');let step=type==='wait'?{type,seconds:Number(input)||1}:type==='ai'?{type,prompt:input}:{type,message:input};return api('/workflows',{method:'POST',body:JSON.stringify({name:fd.get('name'),description:fd.get('description'),steps:[step]})})});
$('#workflowsGrid').addEventListener('click',async e=>{
 const run=e.target.closest('[data-run]'),del=e.target.closest('[data-delete-workflow]');
 if(run){run.disabled=true;run.textContent='Running…';try{const r=await api('/workflows/'+run.dataset.run+'/run',{method:'POST'});await refresh();toast(r.status==='success'?'Workflow completed':'Workflow failed. Check execution history.')}catch(x){toast(x.message)}finally{run.disabled=false;run.textContent='▶ Run'}}
 if(del&&confirm('Delete this workflow?')){try{await api('/workflows/'+del.dataset.deleteWorkflow,{method:'DELETE'});await refresh();toast('Workflow deleted')}catch(x){toast(x.message)}}
});
$('#refreshRuns').onclick=refresh;
async function sendChat(message){const box=$('#chatMessages');box.insertAdjacentHTML('beforeend',`<div class="chat-bubble user">${esc(message)}</div>`);$('#chatInput').value='';try{const r=await api('/chat',{method:'POST',body:JSON.stringify({message})});box.insertAdjacentHTML('beforeend',`<div class="chat-bubble assistant">${esc(r.reply)}</div>`)}catch(e){box.insertAdjacentHTML('beforeend',`<div class="chat-bubble assistant">${esc(e.message)}</div>`)}box.scrollTop=box.scrollHeight}
$('#chatForm').onsubmit=e=>{e.preventDefault();const m=$('#chatInput').value.trim();if(m)sendChat(m)};
document.querySelector('[data-chat]').onclick=()=>{document.querySelector('#chatInput').focus();document.querySelector('.chat-panel').scrollIntoView({behavior:'smooth'})};
(async()=>{try{const h=await api('/health');$('#connection').textContent=h.ai_configured?'AI connected':'System online · AI not configured'};await refresh()}catch(e){$('#connection').textContent='Backend offline';toast('Start the FastAPI backend to use AgentFlow')}})();
